export const data = [
    {
        name: "Maddeh Ahmed Azaiez",
        amount: 100
    },
    {
        name: "Khaled Barkach",
        amount: 150
    },
    {
        name: "Moname Zagoub",
        amount: 40
    },
    {
        name: "Seddik Belaid",
        amount: 50
    },
    {
        name: "Mohamed Kadija",
        amount: 100
    },
    {
        name: "Nassreddine Ben Abdesslem",
        amount: 50
    },
    {
        name: "Amine Sghaier",
        amount: 50
    },
    {
        name: "Firas Rhaiem",
        amount: 50
    },
    {
        name: "Amr Younes",
        amount: 50
    },
    {
        name: "Hamza Amamou",
        amount: 50
    },
    {
        name: "Mouhamed Ennaceur Ben Abdesslem",
        amount: 50
    },
    {
        name: "Khamaies Sahraoui",
        amount: 50
    }
]